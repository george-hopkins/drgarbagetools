package com.drgarbage.test.TestCaseForByteCodeVisualizer;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;

public class TestCaseForByteCodeVisualizer implements Opcodes {

	public static void main(String[] args) {
		try {
			// create the synthetic class
			byte classBytes[] = createClass();

			// deploy the synthetic class
			DeployClassLoader deployClassLoader = new DeployClassLoader();
			Class<? extends Runnable> clazz = deployClassLoader.deploy("GeneratedRunnableImpl", classBytes);
			Runnable runnable = clazz.newInstance();

			// invoke the run() method which should call the static callback() method of this class
			runnable.run();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * creates a class that relates to no java source file but is pure synthetically build at runtime.
	 * It implements {@link Runnable} and it calls the {@link #callback()} method in its run() implementation
	 * 
	 * @return the class bytes that can be deployed in the classloader
	 */
	public static byte[] createClass() {
		ClassWriter cw = new ClassWriter(0);
		MethodVisitor mv;

		// create a class implementing java.lang.Runnable
		cw.visit(49, ACC_PUBLIC + ACC_SUPER, "GeneratedRunnableImpl", null, "java/lang/Object", new String[] { "java/lang/Runnable" });

		// create constructor
		{
			mv = cw.visitMethod(ACC_PUBLIC, "<init>", "()V", null, null);
			mv.visitVarInsn(ALOAD, 0);
			mv.visitMethodInsn(INVOKESPECIAL, "java/lang/Object", "<init>", "()V");
			mv.visitInsn(RETURN);
			mv.visitMaxs(1, 1);
			mv.visitEnd();
		}

		// create implementation of Runnable.run()
		{
			mv = cw.visitMethod(ACC_PUBLIC, "run", "()V", null, null);
			mv.visitMethodInsn(INVOKESTATIC, "TestCaseForByteCodeVisualizer", "callback", "()V");
			mv.visitInsn(RETURN);
			mv.visitMaxs(1, 1);
			mv.visitEnd();
		}

		// finish the class
		cw.visitEnd();
		
		// retrieve the resulting binary java class file format and return it
		byte classBytes[] = cw.toByteArray();
		return classBytes;
	}

	public static void callback() {
		System.out.println("callback called");
	}
}

// This classloader helps to deploy a class at runtime which binaries are given
class DeployClassLoader extends ClassLoader {
	public DeployClassLoader() {
		super(DeployClassLoader.class.getClassLoader());
	}

	public <T> Class<? extends T> deploy(String name, byte[] data) {
		@SuppressWarnings("unchecked")
		Class<? extends T> clazz = (Class<? extends T>) defineClass(name, data, 0, data.length);
		return clazz;
	}
}
